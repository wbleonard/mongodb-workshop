exports = function(country="US", state, city, postalCode, address ){
  
  // Compose Bing Entity Search URL
  const BING_KEY=context.values.get("BingMapKey");
  const requestUrl =encodeURI(`http://dev.virtualearth.net/REST/v1/Locations/${(country||'-')}/${(state||'-')}/${(postalCode||'-')}/${(city||'-')}/${(address||'-')}?includeNeighborhood=1&key=${BING_KEY}`);
  console.log( requestUrl );
  // Get a handle to the Stitch HTTP Service
  const httpService = context.services.get("BingEntitySearch"); // reusing generic HTTP service definition
  
  // Execute the request
  return httpService
    .get({ url: requestUrl,
      headers: {
        // "Ocp-Apim-Subscription-Key": [context.values.get("AzureSubscriptionKey")],
        "content-type": ["application/json"],
        "accept": ["application/json"],
      }
    })
    .then(response => {
      //The response body is encoded as raw BSON.Binary. Parse it to JSON.
      const ejson_body = EJSON.parse(response.body.text());
      return ejson_body;
    });
};
