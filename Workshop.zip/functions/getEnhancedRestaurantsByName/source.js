exports = async function(arg) {
  if( arg === "" ) { return "Invalid argument."; }
  var collection = context.services.get("mongodb-atlas").db("Workshop").collection("Restaurants");
  rxArg = BSON.BSONRegExp( arg );
  var doc = await collection.find( {name: { $regex : rxArg } } ).limit(12);
  if (typeof doc == "undefined" || doc.name === "") {
    return `No restaurants named ${arg} were found.`;
  }

  var list = await doc.toArray();
  for( var i=0; i < list.length; i++ ) {
    var obj = list[i];
    var result = await context.functions.execute("getBingEntityInfo", obj.name ); 
    if ( !result.hasOwnProperty( 'places' ) ) {
      obj.bingEntityInfo = `No Azure data found for ${obj.name}. status=${result.statusCode}`;
    } else {
      obj.bingEntityInfo = result.places.value[0]; // Grab the 1st result
      obj.populatedOn = Date();
    }
  }
  return list;
};
