exports = async function(arg){

  var collection = context.services
    .get("mongodb-atlas").db("Workshop").collection("Restaurants");
  var doc = await collection.findOne({name: arg});
  if (typeof doc == "undefined") {
    return `No restaurants named ${arg} were found.`;
  }
  
  return doc;
}
