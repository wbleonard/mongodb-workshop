exports = async function(payload) {
  
  var restaurant = payload.query.arg || '';
  var newRestaurant = "";
  
  var result = await context.functions.execute("getBingEntityInfo", restaurant);
  if (result.places !== undefined) {
    newRestaurant = result.places.value[0]; // Grab the 1st result
    var address = newRestaurant.address;
    address.zipcode =  address.postalCode;
    address.city =     address.addressLocality;
    address.state =    address.addressRegion;
    newRestaurant.borough = address.neighborhood;
    var latLong = await context.functions.execute("getLatLongInfo", address.addressCountry, address.addressRegion, 
                                                  address.addressLocality, address.postalCode, address.neighborhood );
    newRestaurant.address.coord = latLong.resourceSets[0].resources[0].point.coordinates.reverse();  // lon before lat
    const bingAddr =   (latLong.resourceSets[0].resources[0].address.addressLine || '-');
    address.building = bingAddr.split(' ')[0];
    address.street   = bingAddr.split(' ').slice(1).join(' ');
  } else {
    newRestaurant = {name: restaurant, status: "No place information available for " + restaurant};
  }
  newRestaurant.populatedOn = Date();

  var collection = context.services.get("mongodb-atlas").db("Workshop").collection("Restaurants");
      
  var status = collection.insertOne(newRestaurant);
  console.log(status);
  return newRestaurant;
}
