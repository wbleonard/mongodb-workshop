exports = async function(payload) {
  
  var restaurant = payload.query.arg || '';
  var newRestaurant = "";
  
  var result = await context.functions.execute("getBingEntityInfo", restaurant);
  if (result.places != undefined) {
    newRestaurant = result.places.value[0]; // Grab the 1st result
  } else {
    newRestaurant = {name: restaurant, status: "No place information available for " + restaurant};
  }
  newRestaurant.populatedOn = Date();

  var collection = context.services.get("mongodb-atlas").db("Workshop").collection("Restaurants");
      
  var status = collection.insertOne(newRestaurant);
  console.log(status);
  return newRestaurant;
};
